import frac
print(frac.cont("3_3"))
print(frac.cont("3_345"))
print(frac.cont("0_6"))
#The numbers before the _ are the whole numbers, or the numbers BEFORE the .
#The numbers after the _ will be repeated